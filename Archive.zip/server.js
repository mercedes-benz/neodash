const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors'); // Import the cors middleware

const app = express();
const port = 8080;

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Use cors middleware
app.use(cors());

// Sample data (in-memory database)
let data = [
    { id: 1, name: 'Item 1' },
    { id: 2, name: 'Item 2' },
    { id: 3, name: 'Item 3' }
];

// GET route to retrieve all items
app.get('/items', (req, res) => {
    res.json(data);
});

// GET route to retrieve a specific item by ID
app.get('/items/:id', (req, res) => {
    const itemId = parseInt(req.params.id);
    const item = data.find(item => item.id === itemId);
    console.log('item', item)

    if (item) {
        res.json(item);
    } else {
        res.status(404).json({ message: 'Item not found' });
    }
});

// POST route to add a new item
app.post('/items', (req, res) => {
    const newItem = req.body;
    console.log("🚀 ~ app.post ~ newItem:", newItem)
    newItem.id = data.length + 1;
    newItem.name = data.name;
    data.push(newItem);

    res.status(201).json(newItem);
});

// PUT route to update an existing item by ID
app.put('/items/:id', (req, res) => {
    const itemId = parseInt(req.params.id);
    const updatedItem = req.body;
    updatedItem.id = itemId;

    const index = data.findIndex(item => item.id === itemId);

    if (index !== -1) {
        data[index] = updatedItem;
        res.json(updatedItem);
    } else {
        res.status(404).json({ message: 'Item not found' });
    }
});

// DELETE route to remove an item by ID
app.delete('/items/:id', (req, res) => {
    const itemId = parseInt(req.params.id);
    const index = data.findIndex(item => item.id === itemId);

    if (index !== -1) {
        const deletedItem = data.splice(index, 1)[0];
        res.json(deletedItem);
    } else {
        res.status(404).json({ message: 'Item not found' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
